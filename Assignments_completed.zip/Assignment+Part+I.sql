use supply_db ;


-- Question : Golf related products

/* List all products in categories related to golf. Display the Product_Id, Product_Name in the output. Sort the output in the order of product id.
Hint: You can identify a Golf category by the name of the category that contains golf.

*/

with golf_categories as  #finding the IDs related to golf categories
 ( 
 select id from category
 where name regexp 'golf'
 )
select p.Product_Name,   #joining the golf product IDs with product_info to find their productnames
        p.Product_ID    
from product_info as p
inner join golf_categories as g
ON p.Category_Id= g.id
order by p.Product_Id;             -- ordering by Product_Id

-- **********************************************************************************************************************************

/*
Question : Most sold golf products

Find the top 10 most sold products (based on sales) in categories related to golf. Display the Product_Name and Sales column in the output. Sort the output in the descending order of sales.
Hint: You can identify a Golf category by the name of the category that contains golf.

HINT:
Use orders, ordered_items, product_info, and category tables from the Supply chain dataset.


*/

with filtered_data as
(                                 
select p.Product_Name,                       -- joining all necessary tables
		oi.Sales,
        c.Name as category_name
from category as c
inner join product_info as p
on c.Id= p.Category_Id
inner join ordered_items as oi
on p.Product_Id=oi.Item_Id
where c.Name regexp 'golf'                     -- finding products related to gold categories
)
select Product_Name,
		sum(Sales) as Sales                   -- finding total sum of sales per product and then ordering by total sales in descending order 
from filtered_data
group by Product_Name
order by Sales desc
limit 10;                                      -- finding top 10 costliest products 


-- **********************************************************************************************************************************

/*
Question: Segment wise orders

Find the number of orders by each customer segment for orders. Sort the result from the highest to the lowest 
number of orders.The output table should have the following information:
-Customer_segment
-Orders


*/

select ci.Segment as Segment,       
        count(Order_id) as Orders    #finding number of orders for eacery customer segment
 from customer_info as ci 
 inner join orders as o       #joining Orders table with customer_info based on customer_id
 ON ci.Id= o.Customer_Id    
 group by Segment
 order by Orders desc;         #sorting by descending number of orders

-- **********************************************************************************************************************************
/*
Question : Percentage of order split

Description: Find the percentage of split of orders by each customer segment for orders that took six days 
to ship (based on Real_Shipping_Days). Sort the result from the highest to the lowest percentage of split orders,
rounding off to one decimal place. The output table should have the following information:
-Customer_segment
-Percentage_order_split

HINT:
Use the orders and customer_info tables from the Supply chain dataset.


*/

with Real_Shipping_Days_6
as(
select * from orders as o
inner join customer_info as ci          -- Joining orders table with customer_info table using customer ID 
ON o.Customer_ID= ci.Id 
where Real_Shipping_Days=6                -- filtering for orders with Real_Shipping_Days=6
),
segment_wise_order_count as
(
select Segment as customer_segment,
		count(Order_Id) as count_orders        -- finding order count for each customer segment
from Real_Shipping_Days_6
group by Segment                                -- grouping by customer segment
order by count_orders desc)                       -- ordering by order count
select customer_segment,
		round((count_orders/358)*100, 1) as percentage_order_split       -- finding percentage order split for each customer segment and rounding off to 1 decimal place
from segment_wise_order_count
group by customer_segment
order by percentage_order_split desc;                           -- ordering by percentage_order_split in descending order



-- **********************************************************************************************************************************
